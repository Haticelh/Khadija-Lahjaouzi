#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define TAILLE_MAX 1000
typedef struct {
	int jour;
	int mois;
	int annee;
}date;
typedef struct
{
	int IdVoiture;
    int nbplaces;
	int prixjour;
	char marque[15];
	char nomVoiture[15];
	char couleur[10];
	char EnLocation[4];
	}voiture;
	typedef struct {
		int numContrat;
		int idVoiture;
		int idClient;
		date debut;
		date fin;
		int cout;
	}contrat;
	typedef struct {
		int idClient;
		char nom[20];
		char prenom[20];
		char cin[8];
		char adresse[15];
		int telephone;
	}client;
	// Declaration de la fonction GestionDeVoiture
	void GestionDeVoiture(void);
	// ***************** M E N U*******************
	void Menu(void)
{
	int choixPrincipal,LN;

	 choixPrincipal=MenuPrincipal();

		switch(choixPrincipal)
		{
			case 1 :  system("cls");
			Location();
		    break;
		    case 2 : system("cls");
			GestionDeVoiture();
			case 3 : system("cls");
			GestionClient();
		    break ;
		    case 4 :
		    	 exit(0);
		    default : printf("erreure");
		}

}
//*************Liste_Voiture est une fonction qui permet d'afficher les voitures qui sont dans le fichiers Carlist******************	
	void Liste_Voiture(void)
   {
     FILE* fichier = NULL;
      char chaine[TAILLE_MAX];
      fichier = fopen("ListeDesVoiture.txt","r");
      if (fichier != NULL)
  {
  	          printf("--------------------------------------------------------------------------------\n");
			  printf("  ID ----  MARQUE ----- NOM  ----- COULEURE ---- NBR PLACE ---- PRIX ---- ETAT \n");
			  printf("--------------------------------------------------------------------------------\n");
   	while(fgets(chaine,1000,fichier)!=NULL)
			{
 
			printf("%s   \n",chaine);
		}

    fclose(fichier);
     }
   }
//************************************fonction Ajouter Voiture ****************************************
  void Ajouter_Voiture(void)
{
	int N,i;
	voiture T;
	FILE* liste = NULL;
	liste = fopen("ListeDesVoiture.txt", "a+");
	printf("\n\t\tsaisir le nombre des voiture vou souhaite a ajouter :  ");
	scanf("%d",&N);
if (liste != NULL)
{
    	for(i=0;i<N;i++)
			{

			printf("\n\t\t\t Voiture %d :\n\n",i+1);
			do {
			printf("\t ID           :  ");
			scanf(" %d",&T.IdVoiture);}while(T.IdVoiture<0 || T.IdVoiture>9999);
			printf("\t la marke     :  ");
			scanf("%s",T.marque);
			printf("\t le nom       :  ");
			scanf("%s",T.nomVoiture);
			printf("\t couleur      :  ");
			scanf("%s",T.couleur);
			do{
			printf("\t nbr de place :  ");
			scanf("%d",&T.nbplaces);
			}while(T.nbplaces<0 || T.nbplaces>7);
			printf("\t Prix jour    :  ");
			scanf("%d",&T.prixjour);
			printf("\t l'etat ?     :  ");
			scanf("%s",T.EnLocation);
			fprintf(liste,"\n %d     %s       %s        %s             %d          %d       %s",T.IdVoiture,T.marque,T.nomVoiture,T.couleur,T.nbplaces,T.prixjour,T.EnLocation);
		    }
		}
		fclose(liste);

}
//************************************Fonction Modifier Voiture ********************************************
void Modifier_Voiture(void)
	{
		voiture V;
		char chaine[1000];
		FILE *F=NULL;
		int ID,N,i=0;// la variable N va etre etulisee pour stocker le choix que l'etulisateur va saisie pour specifier quell chose il va modifier 
		F=fopen("ListeDesVoiture.txt","r");
		if(F!=NULL)
       {
		  while (!feof(F))//en va lister les Voitures pour que l'etulisateur peut choisie l'Id de la voiture qu'il veut modifier
    {
    fscanf(F,"%d     %s       %s        %s             %d          %d       %s",&V.IdVoiture,V.marque,V.nomVoiture,V.couleur,&V.nbplaces,&V.prixjour,V.EnLocation);
    printf("\n%d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);
   }
		   fclose(F);
	    printf("\n \n \tsaisire le ID du voiture vous souhait a modifier : ");
		scanf("%d",&ID);
		FILE *file=NULL;
		file=fopen("Tmp.txt","a");
		F=fopen("ListeDesVoiture.txt","r");
		while(!feof(F))
			{
				fscanf(F,"%d %s %s %s %d %d %s",&V.IdVoiture,V.marque,V.nomVoiture,V.couleur,&V.nbplaces,&V.prixjour,V.EnLocation);
			  if(V.IdVoiture!=ID)
			  {
			  	fprintf(file,"\n %d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);
			  
			  }
			 else
			{
				do{
				printf("\t Quelle information vouler vous modifier : \n");
				printf("\n\t \t1- Id               : ");
				printf("\n\t \t2- Marque           : ");
				printf("\n\t \t3- Nom du voiture   : ");
				printf("\n\t \t4- Couleur          : ");
				printf("\n\t \t5- Nombre de places : ");
				printf("\n\t \t6- Prix Jour        : ");
				printf("\n\t \t7- En location ?    : \n");
				printf("\t\t\tChoix : ");
				scanf("%d",&N);
			}while(N<1 ||N>7);
			
			switch(N)
			{
				case 1 : system("cls");
				do{
				printf("\t\t Neauvau ID    : ");
				scanf("%d",&V.IdVoiture);
			}while(V.IdVoiture<0 || V.IdVoiture>9999);// en a fait une boucle do while pour controller la saisie d'etulisateur
				fprintf(file,"\n %d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);
				 i=1;
				break;
				case 2 : system("cls");
				printf("\t\t Neavelle Marque   : ");
				scanf("%s",V.marque);
				fprintf(file,"\n %d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);
				 i=1;
				break;
				case 3 : system("cls");
				printf("\t\t Neavau Nom   : ");
				scanf("%s",V.nomVoiture);
				fprintf(file,"\n %d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);
				 i=1;
				break;
				case 4 : system("cls");
				printf("\t\t Neavelle Couleur   : ");
				scanf("%s",V.couleur);
				fprintf(file,"\n %d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);
				 i=1;
				break;
				case 5 : system("cls");
				do{
				printf("\t\t Neavelle Nombre de places    : ");
				scanf("%d",&V.nbplaces);
			      }while(V.nbplaces<0 || V.nbplaces>7);// meme chose ici , controler le nombre de places ne doit pas depacer 7 places 
				fprintf(file,"\n %d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);
				 i=1;
				break;
				case 6 : system("cls");
				printf("\t\t Neauvau Prix   : ");
				scanf("%d",&V.prixjour);
				fprintf(file,"\n %d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);
				 i=1;
				break;
				case 7 : system("cls");
				printf("\t\t Neavelle Etat   : ");
				scanf("%s",V.EnLocation);
				fprintf(file,"\n %d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);
				 i=1;
				break;
			}
    

			}
		}
		if(i==1)
		{
			printf("\n\t la modification a bien ete effectuee .");
		}
		else
		printf("\n\t Le Id que vous aves saisie n'est pas valide , veuller reessayer a neauvau .");
		fclose(F);
		fclose(file);
		remove("ListeDesVoiture.txt");
		rename("Tmp.txt","ListeDesVoiture.txt");
	}

}//********************************************** fenction Supprimer Voiture *******************************************************

void Supprimer_Voiture(void)
	{
		voiture V;
		FILE *F=NULL;
		FILE *G=NULL;
		int ID,i=0,rep;
		char chaine[1000];
		F=fopen("ListeDesVoiture.txt","r");
		if(F==NULL)
		{
			printf("ERREURE");
		}
		else{ //en va lister les voiture pour que l'utilisateur peut choisir le Id du voiture qu'il veut supprimer
			while(fgets(chaine,1000,F)!=NULL)
			{
			printf("  %s  \n",chaine);
		}
		fseek(F,0,SEEK_SET);// en met le curseur au debut du fichier pour noua permet de faire parcourire le fichier une autre fois en place de le fermer et l'ouvre again .
		printf("\n\n\tsaisire le ID du voiture vous souhait a supprimer : ");
		scanf("%d",&ID);
		printf("\t Voullez vous vraiment supprimer cette voiture ? 1/0 : ");
		scanf("%d",&rep);
		if(rep==1)
		{
		G=fopen("tmp.txt","w");
	      while(fgets(chaine,1000,F)!=NULL)
	      {
	      	if(fscanf(F,"%d %s %s %s  %d  %d  %s",&V.IdVoiture,V.marque,V.nomVoiture,V.couleur,&V.nbplaces,&V.prixjour,V.EnLocation)!=EOF)
	      	  if(V.IdVoiture!=ID)
	      	  {
	      	  	fprintf(G,"\n %d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);
	      	  	i=1;
		      }
	}
     }
    
 }
    if(i==1)
		{
			printf("\n\t la suppression a bien ete effectuee .");
		}
		else
		printf("\n\t Le Id que vous aves saisie n'est pas valide , veuller reessayer a neauvau .");
	fclose(F);
	fclose(G);
	remove("ListeDesVoiture.txt");
    rename("tmp.txt","ListeDesVoiture.txt");

}
// **************************************** Menu Gestion Voiture qui fait l'appelle aux fonctions precedents******************************************* 
	void GestionDeVoiture(void)
{
	int choix;
	int R=0;

	printf("\n                            \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf");
	printf("\n                            \xb3 Gestion De Voiture \xb3");
	printf("\n                            \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9");

    printf("\n\n");
    printf("\n               \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
    printf("\n               \xba                                               \xba");
    printf("\n               \xba    Listes de voitures.....................1   \xba");
    printf("\n               \xba    Ajouter voitures.......................2   \xba");
    printf("\n               \xba    Modifier voiture.......................3   \xba");
    printf("\n               \xba    Supprimer voiture......................4   \xba");
    printf("\n               \xba    Retour.................................5   \xba");
    printf("\n               \xba                                               \xba");
    printf("\n               \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
    printf("\n\n                                Votre choix  :  ");
    scanf("%d",&choix);
    switch(choix)
    {
    	case 1 : system("cls");
		Liste_Voiture();
		// apres avoire lister le voitures  en demande au etulisateur s'il veut contine ou non .si oui , on fait l'appel au Menu Gestion des voiture . sinon en fait sortir du programme
		printf("\n \t \t continue ? 1/0 :   ");
		scanf("%d",&R);
		if(R==1)
		{
			system("cls");
		    GestionDeVoiture();
		}
		else
		exit(0) ;
    	case 2 : system("cls");
		Ajouter_Voiture();
		printf("\n \t \t continue ? 1/0 :   ");
		scanf("%d",&R);
		if(R==1)
		{
			system("cls");
	     	GestionDeVoiture();
	     }
		else
		{
			exit(0) ;
		}
    	case 3 : system("cls");
		Modifier_Voiture();
		printf("\n \t \t continue ? 1/0 :   ");
		scanf("%d",&R);
		if(R==1)
		{
			system("cls");
     		GestionDeVoiture();
     	}
		else
    	exit(0) ;
    	case 4 : system("cls");
		Supprimer_Voiture();
		printf("\n \t \t continue ? 1/0 :   ");
		scanf("%d",&R);
		if(R==1)
		{
		  system("cls");
		  GestionDeVoiture();
	   }
		else
    	exit(0) ;
    	case 5 : system("cls");// si l'utilisateur tape Retour , on fait l'appel au fonction Menu .
    		Menu();
    		
    	default : printf(" erreure");
	}
}
//******************************** Liste des Clients ******************************************
void Liste_Clients(void)
   {
      FILE* F = NULL;
      char chaine[TAILLE_MAX]="";
      F = fopen("Clients.txt","r");
      if (F != NULL)
  {
  	printf("-------------------------------------------------------------------------\n");
  	printf(" ID_CLIENT ---- NOM ---- PRENOM ---- CIN ---- ADDRESS ---- TELEPHONE ----\n");
  	printf("-------------------------------------------------------------------------");
    while (fgets(chaine, TAILLE_MAX,F)!=NULL)
    {
     printf("%s   \n", chaine);
   } 
    fclose(F);
     }
   }
//******************************** Ajouter Client **********************************
	void Ajouter_Client(void)
	{
		FILE* F=NULL;
		F=fopen("Clients.txt","a+");
		int N,i,j;
	    client T[50];
	    if(F!=NULL)
	    {
	    	printf("\t\t combient de Clients vous souhaite a ajouter ? : ");
	    	scanf("%d",&N);
	    	for(i=0;i<N;i++)
	    	{
	    		printf("\t \t\t\t Client %d :\n",i+1);
	    		printf("\t Id client        : ");
	    		scanf("%d",&T[i].idClient);
	    		printf("\t Nom              : ");
	    		scanf("%s",T[i].nom);
	    		printf("\t Prenom           : ");
	    		scanf("%s",T[i].prenom);
	    		printf("\t CIN              : ");
	    		scanf("%s",T[i].cin);
	    		printf("\t Adresse          : ");
	    		scanf("%s",T[i].adresse);
	    		printf("\t Telephone        : ");
	    		scanf("%d",&T[i].telephone);
	    		fprintf(F,"\n   %d       %s     %s    %s    %s     %d ",T[i].idClient,T[i].nom,T[i].prenom,T[i].cin,T[i].adresse,T[i].telephone);
			}
			fclose(F);
		}

//******************************* Modifier Client *******************************
   }
   void Modifier_Client(void)
   {
   	  client C;
   	  char chaine[1000];
   	  int Id,i=0,N;// la variable Id on va l'tilise pour stocker le Id du voiture que l'utilisateur va choisie 
		 // la variable i est pour connaitre si la modificatioon est bien faite ou non 
		 // variable N est pour stocker le choie d'utilisateur ;
   	  FILE *F=NULL,*G=NULL;
   	  F=fopen("Clients.txt","r");
   	  if(F!=NULL)
   	  {
   	  	 while (fgets(chaine, TAILLE_MAX,F)!=NULL)
        {
           printf("%s   \n", chaine);
	    }
     }
    fclose(F);
	 printf("\n\t\t saisire le ID du Client que vous souhait modifier : ");
	 scanf("%d",&Id);

	 F=fopen("Clients.txt","r");
	  if(F!=NULL)
   	  {
   	  	G=fopen("tmp.txt","w");
   	  	if(G!=NULL)
   	  	{
   	  	  while (!feof(F))
        {
        	if(fscanf(F,"%d %s %s %s %s %d",&C.idClient,C.nom,C.prenom,C.cin,C.adresse,&C.telephone)!=EOF)
        	{

        	if(C.idClient!=Id)
        	{
        		fprintf(G,"\n   %d       %s     %s    %s    %s     %d ",C.idClient,C.nom,C.prenom,C.cin,C.adresse,C.telephone);
			}
        	if(C.idClient==Id)
        	{
        		do
        		{
        		printf("\n \t     Veuiller choisire Ce que Vous vOuler Modifier  : \n");
        		printf("\t\t\t Id        ------------- 1\n");
        		printf("\t\t\t Nom       ------------- 2\n");
        		printf("\t\t\t Prenom    ------------- 3\n");
        		printf("\t\t\t CIN       ------------- 4\n");
        		printf("\t\t\t Address   ------------- 5\n");
        		printf("\t\t\t Telephone ------------- 6\n");
        		printf("\t\t\t\t CHOIX : ");
        		scanf("%d",&N);
        		}while(N<1 || N>6);
        		
        		switch(N)
        		{
        			case 1 : system("cls");
        			do {
					printf("\t \t neauvau ID       : ");
					scanf("%d",&C.idClient);
				     }while(C.idClient <0 || C.idClient>9999);
			      	fprintf(G,"\n   %d       %s     %s    %s    %s     %d ",C.idClient,C.nom,C.prenom,C.cin,C.adresse,C.telephone);
                    break;
                    case 2 : system("cls");
                    printf("\t\t neauvau Nom       : ");
                    scanf("%s",C.nom);
                    fprintf(G,"\n   %d       %s     %s    %s    %s     %d ",C.idClient,C.nom,C.prenom,C.cin,C.adresse,C.telephone);
                    break;
                    case 3 : system("cls");
                    printf("\t\t neauvau Prenom    : ");
                    scanf("%s",C.prenom);
                    fprintf(G,"\n   %d       %s     %s    %s    %s     %d ",C.idClient,C.nom,C.prenom,C.cin,C.adresse,C.telephone);
                    break;
                    case 4 : system("cls");
                    printf("\t\t neauvau CIN       : ");
                    scanf("%s",C.cin);
                    fprintf(G,"\n   %d       %s     %s    %s    %s     %d ",C.idClient,C.nom,C.prenom,C.cin,C.adresse,C.telephone);
                    break;
                    case 5 : system("cls");
                    printf("\t\t neauvelle Address : ");
                    scanf("%s",C.adresse);
                    fprintf(G,"\n   %d       %s     %s    %s    %s     %d ",C.idClient,C.nom,C.prenom,C.cin,C.adresse,C.telephone);
                    break;
                    case 6 : system("cls");
					printf("\t\t neauvau Telephone : ");
                    scanf("%d",&C.telephone);
                     
                    fprintf(G,"\n   %d       %s     %s    %s    %s     %d ",C.idClient,C.nom,C.prenom,C.cin,C.adresse,C.telephone);
                    break;
                    
						}
        		
        		i=1;
			}
       }
   }
   }
   if(i==1)
   {
   	printf("\n\t la modifiction a bien ete effectue :");
   }
  }
   fclose(F);
   fclose(G);
   remove("Clients.txt");
   rename("tmp.txt","Clients.txt");

}
//************************************ Supprimer Client *******************************************
   void Supprimer_Client(void)
{
	client  P;
	char chaine[1000];
	FILE *F=NULL;
	FILE *G=NULL;
	int id,i=0,rep;
    F=fopen("Clients.txt","r");
    if(F==NULL)
	printf("erreur\n");
   
    else
    {
		G=fopen("tmp.txt","w");
        if(G==NULL)
             printf("erreur\n");
        else
     { // en va afficher les Clients pour que l'utilisateur peut choisire d'entre eux 
  	     while (fgets(chaine, TAILLE_MAX,F)!=NULL)
        {
           printf("%s   \n", chaine);
	     }
	    fseek(F,0,SEEK_SET); // en remet le cursure vers le debut 
      	printf("\n\n\t entrer le id de client qui vous voulez supprimer: ");
        scanf("%d",&id);
        	printf("\n\t Voullez vous vraiment supprimer ce client ? 1/0 : ");
		scanf("%d",&rep);
		if(rep==1)
		{
  
	while(fgets(chaine,1000,F)!=NULL)

	{
		if(fscanf(F,"%d %s %s %s %s %d",&P.idClient,P.nom,P.prenom,P.cin,P.adresse,&P.telephone)!=EOF)
		{
		   if(P.idClient!=id)
	      fprintf(G,  "\n  %d       %s     %s    %s    %s     %d ",P.idClient,P.nom,P.prenom,P.cin,P.adresse,P.telephone);
	      i=1;
	   }
    }
  }
   }
   if(i==1)
     printf("\n\t\tla suppression de ce Client a ete effectuee avec succes ! ");
     
    fclose(F);
	fclose(G);
 	remove("Clients.txt");
	rename("tmp.txt","Clients.txt");

 }
//********************************************** Menu Gestion Client ***************************************************
}
int GestionClient(void)
{
	int choix,R;
	printf("\n                               \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf");
	printf("\n                               \xb3 Gestion client  \xb3");
	printf("\n                               \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9");
	printf("\n\n");
    printf("\n               \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
    printf("\n               \xba                                               \xba");
    printf("\n               \xba    Liste de client........................1   \xba");
    printf("\n               \xba    Ajouter client.........................2   \xba");
    printf("\n               \xba    Modifier client........................3   \xba");
    printf("\n               \xba    Supprimer client.......................4   \xba");
    printf("\n               \xba    Retour.................................5   \xba");
    printf("\n               \xba                                               \xba");
    printf("\n               \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
    printf("\n\n                                Votre choix  :  ");
    scanf("%d",&choix);
     switch(choix)
    {
    	case 1 : system("cls");
		Liste_Clients();
		printf("\n \t \t continue ? 1/0 :   ");
		scanf("%d",&R);
		if(R==1)
		{
			system("cls");
		    GestionClient();
		}
		else
		exit(0);
    	case 2 : system("cls");
		Ajouter_Client();
		printf("\n \t \t continue ? 1/0 :   ");
		scanf("%d",&R);
		if(R==1)
		{
			system("cls");
	     	GestionClient();
	     }
		else
    	exit(0);
    	case 3 : system("cls");
    	Modifier_Client();
    	printf("\n \t \t continue ? 1/0 :   ");
		scanf("%d",&R);
		if(R==1)
		{
			system("cls");
	     	GestionClient();
	     }
		else
    	exit(0);
    	case 4 : system("cls");
    	Supprimer_Client();
    	printf("\n \t \t continue ? 1/0 :   ");
		scanf("%d",&R);
		if(R==1)
		{
			system("cls");
	     	GestionClient();
	     }
		else
    	exit(0);
    	case 5 :  system("cls");
    		Menu();
    		break;
    	default : printf(" erreure");
}
//*********************************** Visualiser Contrat *********************************
}
		void Visualiser_Contrat(void)
	{
		int ID,c=0;// la variable C est etulisee pour connaitre si le ID que l'utilisateur a entrer est valide ou nn .
		contrat C;
		char chaine[1000];
		FILE *F=NULL;
		F=fopen("Contrat.txt","r");
		if(F!=NULL)
		{
			printf("\n \t saisire votre Contra_ID SVP : ");
			scanf("%d",&ID);
			do{

          	if(fscanf(F," %d   %d   %d   %d/%d/%d   %d/%d/%d   %d",&C.numContrat,&C.idVoiture,&C.idClient,&C.debut.jour,&C.debut.mois,&C.debut.annee,&C.fin.jour,&C.fin.mois,&C.fin.annee,&C.cout)!=EOF)

            if(C.numContrat==ID)
			    {
			    	printf("\n\t \t vous etes deja inscrit avec nous et voici votre contrat : \n");
			    	printf("\n\t\t NumContrat  || ID_Voiture   || ID_Client   || Date debut    || Date fin    || Cout ");
			    	printf("\n\t\t ------------  --------------  -------------  ---------------  -------------  ------");
			    	printf("\n\t\t %d        || %d         || %d        || %d/%d/%d    || %d/%d/%d  || %d DH\n\t",C.numContrat,C.idVoiture,C.idClient,C.debut.jour,C.debut.mois,C.debut.annee,C.fin.jour,C.fin.mois,C.fin.annee,C.cout);
			       c=1;
				}
			}while(fgets(chaine,1000,F)!=NULL);
			if(c==0)
					printf(" Ce ID que vous aves entres n'existe pas , si vous voulez vous pouvez passer au menu precedent pour vous Ajouter, Merci.");

			fclose(F);

		}
		else{
			printf("erreur ");
		}
	}
 //cette fonction en l'etuliser pour calculer le Cout de chaque personne, elle a comme parametre le jour de debut et le jour du fn et le prix du voiture selectionee .
	int Cout(int debutj,int finj,int prixV)
	{
		int cout;
		int jour;
		if(finj>debutj)
		{
			jour=finj-debutj;
		}
		else
		{
			jour=30-(debutj-finj);
		}
		cout=jour*prixV;

		return cout;

	}
// cette fonction en l'etulise pour ajouter la cotntra que l'etulisateur va saisir et en va la stocker avec les autres contrats
	void Ajouter_Contrat(int PrixV)
	{
		contrat C;
		FILE *F=NULL,*G=NULL;
		F=fopen("Contrat.txt","a+");
		if(F!=NULL)
		{
			printf("\n\t Num contrat    : ");
			scanf("%d",&C.numContrat);
			printf("\t ID voiture       : ");
			scanf("%d",&C.idVoiture);
			printf("\t ID Client        : ");
			scanf("%d",&C.idClient);
			printf("\t Date debut       : ");
			scanf("%d %d %d",&C.debut.jour,&C.debut.mois,&C.debut.annee);
			printf("\t Date fin         : ");
			scanf("%d %d %d",&C.fin.jour,&C.fin.mois,&C.fin.annee);
			C.cout=Cout(C.debut.jour,C.fin.jour,PrixV);
			fprintf(F,"\n %d   %d   %d   %d/%d/%d   %d/%d/%d   %d Dh",C.numContrat,C.idVoiture,C.idClient,C.debut.jour,C.debut.mois,C.debut.annee,C.fin.jour,C.fin.mois,C.fin.annee,C.cout);
		}
		fclose(F);
	}
	// cette fenction en va l'etuliser pour changer l'attribut "non" du fichier voiture a "oui" 
void Ajouter_Oui(int Vid,FILE *H)
	{
		
		voiture V;
		fclose(H);
		FILE *F=NULL;
		F=fopen("ListeDesVoiture.txt","r");
		if(F!=NULL)
       {
		FILE *file=NULL;
		file=fopen("Tmpl.txt","a");
		while(!feof(F))
			{
				if(fscanf(F,"%d %s %s %s %d %d %s",&V.IdVoiture,V.marque,V.nomVoiture,V.couleur,&V.nbplaces,&V.prixjour,V.EnLocation)!=EOF)
				{

			  if(V.IdVoiture!=Vid)
			  {
			  	fprintf(file,"\n %d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);
			  }
			 else
			{
				strcpy(V.EnLocation,"oui");
		    	fprintf(file,"\n %d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);
		    	printf("\n\t VOTRE CONTAT A BIEN ETE CREE ! MERCI POUR NOUS CHOISIE  .");
			}
		}
	}
		fclose(F);
		fclose(file);
		remove("ListeDesVoiture.txt");
		rename("Tmpl.txt","ListeDesVoiture.txt");
	}

}
//**************************** fenction Louer Voiture *************************************
	void Louer_Voiture(void)
	{
		date debut,fin;
		client C;
		voiture V;
		int rep;
		contrat Nvcontrat;
		int aide=0,tmp=0,numcontrat,PrixV;
		FILE *F=NULL,*G=NULL,*H=NULL;
		char nom[20],prenom[20];
		int IdVoiture;

		printf("\n\t Veillez entrer les informations suivants : \n");
		printf("\t\t Nom      : ");
		scanf("%s",nom);
		printf("\t\t Prenom   : " );
		scanf("%s",prenom);
		printf("\t\t ID du voiture vous souhaite a louer : ");
		scanf("%d",&IdVoiture);
		F=fopen("Clients.txt","r");
		G=fopen("ListeDesVoiture.txt","r");
		H=fopen("Contrat.txt","r");
		if(F!=NULL)
		{
			do
			{
				fflush(stdin);
				fscanf(F,"  %d       %s     %s    %s    %s     %d",&C.idClient,C.nom,C.prenom,C.cin,C.adresse,&C.telephone);
				if(strcmp(C.nom,nom)==0 && strcmp(C.prenom,prenom)==0)
				{
				   aide=1;
				}
			}while(!feof(F));
			fseek(F,0,SEEK_SET);// en met le cursur vers le debut 
		}
			else
			{
				printf("erreure");
			}
			if(G!=NULL);
			{
		    	do
		    	{
			  fscanf(G,"%d %s %s %s %d %d %s",&V.IdVoiture,V.marque,V.nomVoiture,V.couleur,&V.nbplaces,&V.prixjour,V.EnLocation);
			  if(V.IdVoiture==IdVoiture)
			  {
	             	tmp=1;
	             	PrixV=V.prixjour;
	             }
		        }while(!feof(G));

			}
			if(G==NULL){
				printf("erreure");
			}
			if(aide==1)
			{
				if(tmp==1)
				{
					fseek(G,0,SEEK_SET);
					do
					{
						if(fscanf(G,"%d %s %s %s %d %d %s",&V.IdVoiture,V.marque,V.nomVoiture,V.couleur,&V.nbplaces,&V.prixjour,V.EnLocation)!=EOF)  
                      {

						if(strcmp(V.EnLocation,"oui")==0 &&  V.IdVoiture==IdVoiture)
						{
							printf("\n\t CETTE VOITURE EST DEJA LOUER A QULQ'UN , VEULLER CHOISIRE UNE AUTRE , MERCI.");
							fclose(F);
	                     	fclose(G);
	                     	fclose(H);
							break;
						}
							if(strcmp(V.EnLocation,"non")==0 &&  V.IdVoiture==IdVoiture)
						{
							if(H!=NULL)
							{
							Ajouter_Contrat(PrixV);
							Ajouter_Oui(V.IdVoiture,G);
							
							break;
					     	} 
					     						     	 

						}
					
					}
				}while(!feof(G));
			}
				else
				{
					printf("VOU ETES DEJA INSCRIT AVEC NOUS , MAIS LA VOITURE QUE VOUS AVES CHOISIE N'EXISTE PAS ! ");
				}

			}
			else{
				printf("\n VOUS NETES PAS INSCRIT AVEC NOUS ,VOULLEZ VOUS VOUS AJOUTER MAINTENANT ? 1/0 : ");
				scanf("%d",&rep);
				switch (rep)
				{
					case 1 : system("cls");
					  	FILE* F=NULL;
		F=fopen("Clients.txt","a+");
		int N,i,j;
	    client T;
	    if(F!=NULL)
	    {

	    		
	    		printf("\t Id client        : ");
	    		scanf("%d",&T.idClient);
	    		printf("\t Nom              : ");
	    		scanf("%s",T.nom);
	    		printf("\t Prenom           : ");
	    		scanf("%s",T.prenom);
	    		printf("\t CIN              : ");
	    		scanf("%s",T.cin);
	    		printf("\t Adresse          : ");
	    		scanf("%s",T.adresse);
	    		printf("\t Telephone        : ");
	    		scanf("%d",&T.telephone);
	    		fprintf(F,"\n   %d       %s     %s    %s    %s     %d ",T.idClient,T.nom,T.prenom,T.cin,T.adresse,T.telephone);
			}
			fclose(F);
					break;
					case 0 : system("cls");
					break;
					default : printf("veiller entrer 1 ou 0 ");
				}
			}
		fclose(H);
		fclose(F);
		fclose(G);
		
	}
	// cette fonction la en va l'etuliser pour changer "oui" a "non", c a d rendre la voiture disponible a louer
		void Ajouter_non(int Vid ,FILE* H)
	{
		voiture V;
		fclose(H);
		FILE *F=NULL,*file=NULL;
		F=fopen("ListeDesVoiture.txt","r");
		file=fopen("Tmp.txt","a");
		if(F!=NULL)
       {
		
		while(!feof(F))
			{
				fscanf(F," %d     %s       %s        %s             %d          %d       %s",&V.IdVoiture,V.marque,V.nomVoiture,V.couleur,&V.nbplaces,&V.prixjour,V.EnLocation);
			  if(V.IdVoiture!=Vid)
			  {
			  	fprintf(file,"\n %d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);
			  }
			 if(V.IdVoiture==Vid)
			{

				strcpy(V.EnLocation,"non");
		    	fprintf(file,"\n %d     %s       %s        %s             %d          %d       %s",V.IdVoiture,V.marque,V.nomVoiture,V.couleur,V.nbplaces,V.prixjour,V.EnLocation);

			}
		}
		fclose(F);
		fclose(file);
		remove("ListeDesVoiture.txt");
		rename("Tmp.txt","ListeDesVoiture.txt");
 	}
}
// cette fonction en va l'etuliser pour suprimer la contrat apres que l'utilisateur retourner la voiture .elle va travailler automatiquement
void Supprimer_contrat(int numcontrat)
{
	contrat C;
	FILE *F=NULL,*G=NULL;
	char chaine[1000];
	F=fopen("Contrat.txt","r");
	G=fopen("tmp.txt","w");
	if(F!=NULL)
	{
		do
		{ if(fscanf(F,"%d   %d   %d   %d/%d/%d   %d/%d/%d   %d",&C.numContrat,&C.idVoiture,&C.idClient,&C.debut.jour,&C.debut.mois,&C.debut.annee,&C.fin.jour,&C.fin.mois,&C.fin.annee,&C.cout)!=EOF)
          {
		   if(C.numContrat!=numcontrat)
		   {
		   	if(G!=NULL)
		   	{
		   		fprintf(G,"\n %d   %d   %d   %d/%d/%d   %d/%d/%d   %d",C.numContrat,C.idVoiture,C.idClient,C.debut.jour,C.debut.mois,C.debut.annee,C.fin.jour,C.fin.mois,C.fin.annee,C.cout);
		   		
			   }
		   }
		
	}
		}while(fgets(chaine,1000,F));
	}
	
	printf("\n \t la contrat a bien ete supprimee ");
	fclose(F);
	fclose(G);
	remove("Contrat.txt");
	rename("tmp.txt","Contrat.txt");
}
// cella en va l'utoiliser pour supprimer le client de la liste des clients apres qu'il retourner la voiture
void supprimer_Client(int IdClient)
{
	client C;
	FILE *F=NULL,*G=NULL;
	F=fopen("Clients.txt","r");
	G=fopen("tmp.txt","w");
	if(F!=NULL)
	{
		do
		{
			   if( fscanf(F," %d       %s     %s    %s    %s     %d",&C.idClient,C.nom,C.prenom,C.cin,C.adresse,&C.telephone)!=EOF)
        {
		   if(C.idClient!=IdClient)
		   {
		   	if(G!=NULL)
		   	{
		   		fprintf(G,"\n  %d       %s     %s    %s    %s     %d",C.idClient,C.nom,C.prenom,C.cin,C.adresse,C.telephone);
			   }
		   }
	}
		}while(!feof(F));
	}
	printf("\n \t le Client a bien ete supprimee ");
	fclose(F);
	fclose(G);
	remove("Clients.txt");
	rename("tmp.txt","Clients.txt");
}
//******************************* Retourner Voiture **********************************
void Retourner_Voiture(void)
{
	int Idvoiture,Numcontrat,Idclient,pos;
	int aide1,aide2,aide3;
	voiture V;
	client C;
	contrat T;
	FILE *F=NULL,*G=NULL,*H=NULL;
	F=fopen("ListeDesVoiture.txt","r");
	G=fopen("Clients.txt","r");
	H=fopen("Contrat.txt","r");
	printf("\t\t Veiller entre les information suivant : \n");
	printf("\t Numero de Contrat     : ");
	scanf("%d",&Numcontrat);
	printf("\t Id du Voiture         : ");
	scanf("%d",&Idvoiture);
	printf("\t Id Client             : ");
	scanf("%d",&Idclient);
	if(G!=NULL)
	{
		do
		{
			if( fscanf(G," %d       %s     %s    %s    %s     %d",&C.idClient,C.nom,C.prenom,C.cin,C.adresse,&C.telephone)!=EOF)
			{
				
				if(Idclient==C.idClient)
				aide1=1;
			}
		}while(!feof(G));
	
		fclose(G);
	}
	else printf("errure");
	if(H!=NULL)
	{
		while(!feof(H))
		{
			if(fscanf(H,"%d   %d   %d   %d/%d/%d   %d/%d/%d   %d",&T.numContrat,&T.idVoiture,&T.idClient,&T.debut.jour,&T.debut.mois,&T.debut.annee,&T.fin.jour,&T.fin.mois,&T.fin.annee,&T.cout)!=EOF)
			if(Numcontrat==T.numContrat)
			aide2=1;
		}
		
		fclose(H);
	}
		else printf("errure");
	if(F!=NULL)
	{
		while(!feof(F))
		{
			if(fscanf(F,"%d %s %s %s %d %d %s",&V.IdVoiture,V.marque,V.nomVoiture,V.couleur,&V.nbplaces,&V.prixjour,V.EnLocation)!=EOF)
			if(Idvoiture==V.IdVoiture)
			aide3=1;
			
		}
		
		fclose(F);
	}
		else printf("errure");
	F=fopen("ListeDesVoiture.txt","r");
	if(aide1==1)
	{
	   if(aide2==1)
	   {
	        if(aide3==1)
	          {
			    if(F!=NULL)
	{
		do
		{
			if(fscanf(F,"%d %s %s %s %d %d %s",&V.IdVoiture,V.marque,V.nomVoiture,V.couleur,&V.nbplaces,&V.prixjour,V.EnLocation)!=EOF)
         {
		 
			if(V.IdVoiture==Idvoiture)
			{ 
			
				Ajouter_non(Idvoiture,F);
				Supprimer_contrat(Numcontrat);
				supprimer_Client(Idclient);
				break;
							}
		}
		}while(!feof(F));
	}
}
}
}
	
	if(aide1!=1) printf("\n\t Ce client n'existe pas veiller re choisire un ID CLIent valide svp ");
	if(aide2!=1) printf("\n\t Cette Contra n'existe pas veiller rechoisire un ID Contrat valide svp");
	if(aide3!=1) printf("\n\t cette voiture n'existe pas veiller rechoisire un ID voiture valide svp");
	printf("\n\n\t MERCI POUR NOUS CHOISIE , A BIENTOT !");
	fclose(F);

}
// ***************************************** Modifier Contrat ******************************************
void Modifier_Contrat(void)
{
	int Id,prix;
	contrat C;
	voiture V;
	FILE *F=NULL,*G=NULL,*H=NULL;
	F=fopen("Contrat.txt","r");
	G=fopen("tmp.txt","w");
	H=fopen("ListeDesVoiture.txt","r");
	printf("\n\t\t Entrer le numero du contrat que vous souhaite la modifier : ");
	scanf("%d",&Id);
	if(F!=NULL)
	{
		do
		{
	       fscanf(F," %d   %d   %d   %d/%d/%d   %d/%d/%d   %d",&C.numContrat,&C.idVoiture,&C.idClient,&C.debut.jour,&C.debut.mois,&C.debut.annee,&C.fin.jour,&C.fin.mois,&C.fin.annee,&C.cout);
           if(C.numContrat==Id)
           {
           	 printf("\n\t\tcett contrat commance le %d/%d/%d ,Entrer La Nouvelle date de fin    : ",C.debut.jour,C.debut.mois,C.debut.annee);
           	 scanf("%d %d %d",&C.fin.jour,&C.fin.mois,&C.fin.annee);
           	 if(H!=NULL)
           	 {
           	 	do
           	     { fflush(stdin);
					fscanf(H,"\n %d     %s       %s        %s             %d          %d       %s",&V.IdVoiture,V.marque,V.nomVoiture,V.couleur,&V.nbplaces,&V.prixjour,V.EnLocation);
	                if(V.IdVoiture==C.idVoiture)
	                {
	                	prix=V.prixjour;
					}
				}while(!feof(H));
			}
			else
			{
				printf("erreure");
				}	
           	 if(G!=NULL)
           	 {
           	 	C.cout=Cout(C.debut.jour,C.fin.jour,prix);
           	 	fprintf(G,"\n %d   %d   %d   %d/%d/%d   %d/%d/%d   %d",C.numContrat,C.idVoiture,C.idClient,C.debut.jour,C.debut.mois,C.debut.annee,C.fin.jour,C.fin.mois,C.fin.annee,C.cout);
				}
				else
				{
					printf("erreure");
				}
		   }
		   else
		   {
		   	
           	 fprintf(G,"\n %d   %d   %d   %d/%d/%d   %d/%d/%d   %d",C.numContrat,C.idVoiture,C.idClient,C.debut.jour,C.debut.mois,C.debut.annee,C.fin.jour,C.fin.mois,C.fin.annee,C.cout);

		   }
		}while(!feof(F));
	}
	printf("\n\t la modification a bien ete effectuee !");
	fclose(F);
	fclose(G);
	fclose(H);
	remove("Contrat.txt");
	rename("tmp.txt","Contrat.txt");
}

	int Location(void)
{
	int rep,Id;
	int choix;
	printf("\n                               \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf");
	printf("\n                               \xb3     Location    \xb3");
	printf("\n                               \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9");
	printf("\n\n");
	printf("\n               \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
    printf("\n               \xba                                                 \xba");
    printf("\n               \xba    Visualier contra.........................1   \xba");
    printf("\n               \xba    Louer Voiture............................2   \xba");
    printf("\n               \xba    Retourner voiture........................3   \xba");
    printf("\n               \xba    Modifier contrat.........................4   \xba");
    printf("\n               \xba    Supprimer contra.........................5   \xba");
    printf("\n               \xba    Retour...................................6   \xba");
    printf("\n               \xba                                                 \xba");
    printf("\n               \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
    printf("\n\n                                Votre choix  :  ");
    scanf("%d",&choix);
    switch(choix)
    {
    	case 1 : system("cls");
    	Visualiser_Contrat();
    	printf("\n\t\t Contine ? 0/1 : ");
    	scanf("%d",&rep);
    	if(rep==1)
    	{
    		system("cls");
    		Location();
		}
		if(rep==0)
		{
			exit(0);
		}
		case 2 : system("cls");
		Louer_Voiture();
		printf("\n\t\t Contine ? 0/1 : ");
    	scanf("%d",&rep);
    	if(rep=1)
    	{
    		system("cls");
    		Location();
		}
		if(rep==0)
		{
			exit(0);
		}
		case 3 : system("cls");
		Retourner_Voiture();
		printf("\n\t\t Contine ? 0/1 : ");
    	scanf("%d",&rep);
    	if(rep=1)
    	{
    		system("cls");
    		Location();
		}
		if(rep==0)
		{
			exit(0);
		}
		case 4 : system("cls");
		Modifier_Contrat();
		printf("\n\t\t Contine ? 0/1 : ");
    	scanf("%d",&rep);
    	if(rep=1)
    	{
    		system("cls");
    		Location();
		}
		if(rep==0)
		{
			exit(0);
		}
		case 5 : system("cls");
		 printf("\n\t\t Entrer votre contrat ID pour la supprimer : ");
		 scanf("%d",&Id);
		 Supprimer_contrat(Id);
		 printf("\n\t\t Contine ? 0/1 : ");
    	scanf("%d",&rep);
    	if(rep=1)
    	{
    		system("cls");
    		Location();
		}
		if(rep==0)
		{
			exit(0);
		}
		case 6 : system("cls");
		   Menu();
    		break;
    	default : printf(" erreure");


	}
}
	int MenuPrincipal()
{
    int choix;

	printf("\n                               \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf");
	printf("\n                               \xb3 Menu Principal  \xb3");
	printf("\n                               \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9");

    printf("\n\n");

    printf("\n               \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
    printf("\n               \xba                                              \xba");
    printf("\n               \xba    Location..............................1   \xba");
    printf("\n               \xba    Gestion voitures......................2   \xba");
    printf("\n               \xba    Gestion clients.......................3   \xba");
    printf("\n               \xba    Quitter...............................4   \xba");
    printf("\n               \xba                                              \xba");
    printf("\n               \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
    printf("\n\n                                Votre choix  :  ");

    scanf("%d",&choix);
    
    return choix;
}





	void main(void)
	{  int choixPrincipal,LN;

	 choixPrincipal=MenuPrincipal();

		switch(choixPrincipal)
		{
			case 1 :  system("cls");
			Location();
		    break;
		    case 2 : system("cls");
			GestionDeVoiture();
			case 3 : system("cls");
			GestionClient();
		    break ;
		    case 4 :
		    	 exit(0);
		    default : printf("erreure");
		}

	}
